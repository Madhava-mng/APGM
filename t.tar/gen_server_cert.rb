require 'io/console'
require 'base64'


def get_passprase

  tmp_pass = IO::console.getpass("password-for-cert: ⚷ ")
  print "\e[A\e[18C  #{"*"*tmp_pass.length}\n"
  retry_pass = IO::console.getpass("retype-password: ⚷ ")
  print "\e[A\e[16C  #{"*"*retry_pass.length}\n"

  if tmp_pass == retry_pass
    puts "[Success] Don't forgot It. clint can't connect without password.\n"
    sleep 1
    if tmp_pass.length == 0
        tmp_pass = "s3cr3t_APGM"
    end

  else
    puts "[Error]  Password not match. please try again.\n"
    exit
  end

    return tmp_pass
end

class Gen
  attr_accessor :name,:passwd,:info,:host,:pub_key


  def initialize


    # inputs

    print "Group-Name\e[32m*\e[0m: "
    name = gets.chomp.strip

    if name == ""
      puts "\e[A\r[Error] Group-Name require."
      exit
    elsif name.length < 4
      puts "\e[A\r[Error] Group-Name must have length of 4\n"
      exit
    end

    print "Group-Info: "
    info = gets.chomp.strip

    if info == ""
      @info = "APGM hosted @#{name.strip}"
    else
      @info = info
    end

    print "\e[A\e[12C#{@info}\n"
    
    @passwd = get_passprase
    @name = name

    
    # get hostname

    if File.file? 'hostname'
      File.open("hostname", "r") do |f|
        @host = f.readline.chomp
      end
    else
      puts "[Error] unable to get hostname.\nMake sure u installed all dependency, or Run the command in it's dir."
      exit
    end

    system "openssl genrsa -out .keys/server/#{@name}"
    system "openssl rsa -in .keys/server/#{@name} -pubout > .keys/server/#{@name}.pub"

    # get public key

    if File.file? ".keys/server/#{@name}.pub"
      File.open(".keys/server/#{@name}.pub", "rb") do |f|
        @pub_key = f.read.chomp
        @pub_key = Base64::strict_encode64 @pub_key
      end

    else
      puts "[Error] unable to get gey\nMake sure u installed openssl."
      exit
    end





    puts "Group-Name: #{@name}"
    puts "Group-Info: #{@info}"
    puts "Group-Host: #{@host}"
    puts "Group-Password: #{'*'*@passwd.length}"


    # confirm user
    #
    print "The given info is correct ? \e[2my/yes\e[0m\e[5D"
    if ['y', 'yes'].include? gets.chomp.strip
      sleep 0.6
      print "\e[A                                         "
      puts "\r[Success] Certificate created."
    else
      sleep 0.4
      print "\e[A                                         "
      puts "\r[Exited] Certificate Not created"
      exit
    end

    


  end

  def creat

    puts "[creating] certificate..."

    # skeleton

    buffer = ""

    buffer += "SERVER_NAME=#{@name}\n"
    buffer += "SERVER_KEY=#{@pub_key}\n"
    buffer += "SERVER_INFO=#{@info}\n"
    buffer += "SERVER_HOST=#{@host}\n"


    # write fifo

    Thread::new {
      File.open("crypto/cert", "w") do |f|
        f.write(buffer)
      end
    }



    # read fifo on shell

    system "cat crypto/cert | openssl aes-192-cbc -k #{@passwd} -iter 519 |base64 > certs/server/#{@name}.apgm"


    if File.file?("certs/server/#{@name}.apgm")
      puts "[Saved] to certs/server/#{@name}.apgm"

      File.open("certs/server/plain/#{@name}.apgm", "wb") do |f|
        f.write(buffer)
      end
    else
      puts "[Error] certificate not created."
    end

  end

end

a = Gen::new()
a.creat









=begin


    if Process::uid == 0

      if File.exist?("/etc/tor")

        # rewrite /etc/tor/torrc
        # backup too

        system "cp /etc/tor/torrc /etc/tor/torrc.backup 2>/dev/null"
        system "cp /etc/tor/torrc.sample /etc/tor/torrc.sample.backup 2>/dev/null"

        if File.file? ("/etc/tor/torrc")
          File.open("/etc/tor/torrc","a") do |f|
            f.write("%include /etc/tor/#{@name}}\n")
          end

        elsif File.file? ("/etc/tor/torrc.sample")
          File.open("/etc/tor/torrc.sample", "a") do |f|
            f.write("%include /etc/tor/#{@name}}\n")
          end
        
        else
          print "[help] Unable to locate torrc file.\nIt inside /etc/tor/<file>\n"
          print "please enter full path for the configaration file: "
          path = gets.chomp

          if File.file? (path)
            File.open(path, "a") do |f|
              f.write("%include /etc/tor/#{@name}}\n")
            end
          else
            print "[Error] Given path '#{@path}' is not exist.\n"
            print "do some enumeration on '/etc/tor/' and try again.\n"
            exit
          end
        end

        # write configaration file

        File.open("/etc/tor/#{@name}", "w") do |f|
          data = "HiddenServiceDir /var/lib/tor/apgm/#{@name}/\n"
          data += "HiddenServicePort #{@port} 127.0.0.1:#{@port}\n"
          f.write(data)
        end
=end
