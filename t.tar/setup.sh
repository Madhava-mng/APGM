#!/bin/sh

if [ `id -u` -ne 0 ]
then
	printf "\e[31m[Error]\e[0m Need root previlage.\n"
	exit
fi


# packages

for i in  tor ruby openssl nc
do
	which $i > /dev/null
	if [ $? -ne 0 ]
	then
		printf "\e[31m[ Failed ]\e[0m Package \e[36m$i\e[0m not found.\n   \`---> please Install $i.\n"
		exit
	else
		printf "\e[32m[Success*]\e[0m Package \e[36m$i\e[0m found.\n"
	fi
done


# mkfifo

mkfifo crypto/cert 2>/dev/null



which openssl > /dev/null

if [ $? -eq 0 ]
then
	# openssl ciphers

	for i in `openssl list -cipher-commands|grep -v 'base64'|grep -v zlib`
	do
		echo $i
	done > ciphers


	# ssh key gen
	
	printf "\n\n\n\e[32m[+]\e[0m  \e[36m-->\e[0m "
	openssl genrsa -out .keys/clint/idrsa

	# pub creation
	openssl rsa -in .keys/clint/idrsa -pubout > .keys/clint/idrsa.pub
	printf "\e[32m[+]\e[0m Public key added.\n"
fi

which tor > /dev/null

if [ $? -eq 0 ]
then
	# append torrc file

	data="HiddenServiceDir /var/lib/tor/apgm/\n"
	data=$data"HiddenServicePort 80 127.0.0.1:10050\n"

	if [ -f /etc/tor/torrc ]
	then
		cat /etc/tor/torrc | grep apgm > /dev/null

		if [ $? -ne 0 ]
		then
			printf "$data"  >> /etc/tor/torrc
		fi

	elif [ -f /etc/tor/torrc.sample ]
	then
		cp /etc/tor/torrc.sample /etc/tor/torrc
		printf "$data"  >> /etc/tor/torrc
	else
		printf "\n\n[help] tor config file not found.\n"
		printf "It maybe in /etc/tor/\n"
		printf "Type the file name with path : \e[2m/etc/tor/file\e[0m\e[13D"
		read path

		if [ -f $path ]
		then
			printf "$path ?  "
			sleep 0.3
			printf " got it.\n"

			cat $path | grep apgm > /dev/null

			if [ $? -ne 0 ]
			then
				printf $data >> $path

			fi

		else
			printf "\e[31m[Fail]\e[0m $path file not found.\n\n\t[please try after sometimes]\n\n"
			exit
		fi
	fi

	# kill process

	printf "kill and restart tor service .................... [return to continue] "
	read

	nc -lvn 10050&

	killall tor 2>/dev/null

	printf "\e[32m[*]\e[0m Please wait.\n"

	tor&

	sleep 20

	cat /var/lib/tor/apgm/hostname > hostname
	killall nc >/dev/null
	chmod 444 hostname

fi




